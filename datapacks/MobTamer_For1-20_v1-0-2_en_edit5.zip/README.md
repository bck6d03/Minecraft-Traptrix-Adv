# MobTamer v1.0.2 For 1.20.1

Twitter: @keeema_1

For Minecraft Java Edition version 1.20.1


配布ページの注意点を読んでからプレイすることを推奨します。
We recommend that you read the notes on the distribution page before playing.

配布ページURL:  
https://github.com/Keeema-1/MobTamer/wiki

Distribution Page:  
https://github.com/Keeema-1/MobTamer/wiki/Home_EN

ライセンス/LICENSE  
MIT License (https://github.com/Keeema-1/MobTamer/blob/main/LICENSE)


加工點:
把生物靜音掉
Silent:1b

