Traptrix Texture pack: 
change skeleton as player models

sera
dionaea
allomerus
vesiculo
myrmeleo
genlisea
rafflesia
nepenthes
atrax
mantis
cularia
pudica
arachnocampa
pinguicula
atypus
holeutea




maid sound pack

